#!/bin/bash
export LD_LIBRARY_PATH=/home/cott/opt/gcc4.2/lib64
